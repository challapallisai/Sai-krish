var jwt = require('jsonwebtoken');
var payload = {
  sub: '1234567890',
  name: 'John Doe',
};
var options = {
  expiresIn: '1h'
};
var token = jwt.sign(payload, 'your_secret_key', options);
var response = {
  'jwtToken': token
};
session.output.write(JSON.stringify(response));